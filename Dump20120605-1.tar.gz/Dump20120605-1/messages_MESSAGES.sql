CREATE DATABASE  IF NOT EXISTS `messages` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `messages`;
-- MySQL dump 10.13  Distrib 5.1.62, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: messages
-- ------------------------------------------------------
-- Server version	5.1.62-0ubuntu0.11.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `MESSAGES`
--

DROP TABLE IF EXISTS `MESSAGES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MESSAGES` (
  `idMESSAGES` int(11) NOT NULL AUTO_INCREMENT,
  `DENUMIRE` varchar(150) NOT NULL,
  `DESCRIERE` varchar(450) NOT NULL,
  `FK_ID_TOPIC` int(11) NOT NULL,
  `LASTMODIFIED` datetime DEFAULT NULL,
  PRIMARY KEY (`idMESSAGES`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MESSAGES`
--

LOCK TABLES `MESSAGES` WRITE;
/*!40000 ALTER TABLE `MESSAGES` DISABLE KEYS */;
INSERT INTO `MESSAGES` VALUES (1,'mesaj1','mesaj1',1,'2012-06-04 23:26:31'),(2,'mesaj2','mesaj2',1,'2012-06-04 23:26:31'),(3,'mesaj3','mesaj3',2,'2012-06-04 23:26:31'),(4,'mesaj4','mesaj4',1,'2012-06-04 23:26:31'),(5,'mesaj5','mesaj5',1,'2012-06-04 23:26:31'),(6,'mesaj6','mesaj6',2,'2012-06-04 23:26:31'),(7,'mesaj7','mesaj7',1,'2012-06-04 23:26:31'),(8,'mesaj8','mesaj8',1,'2012-06-04 23:26:31'),(9,'mesaj9','mesaj9',2,'2012-06-04 23:26:31'),(10,'data=1','firstmessage modified',3,'2012-06-05 19:43:27'),(11,'data=1','firstmessage modified',4,'2012-06-05 19:59:08'),(12,'data=1','firstmessage modified',5,'2012-06-05 20:17:16'),(13,'data=1','firstmessage modified',6,'2012-06-05 20:18:59'),(14,'data=1','firstmessage modified',7,'2012-06-05 20:21:24'),(15,'data=1','firstmessage modified',8,'2012-06-05 20:25:08'),(16,'data=1','firstmessage modified',9,'2012-06-05 20:29:11');
/*!40000 ALTER TABLE `MESSAGES` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-06-05 22:50:06
